// API URL
const API_URL = 'http://localhost:3000/api';

// DOM Elements
const memberForm = document.getElementById('memberForm');
const membersList = document.getElementById('membersList');
const searchInput = document.getElementById('searchInput');

let members = [];

// Fetch all members
async function fetchMembers() {
  try {
    const response = await fetch(`${API_URL}/members`);
    members = await response.json();
    renderMembers();
  } catch (error) {
    console.error('Error fetching members:', error);
  }
}

// Add new member
memberForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const member = {
    name: document.getElementById('name').value,
    email: document.getElementById('email').value,
    phone: document.getElementById('phone').value,
  };
  
  try {
    const response = await fetch(`${API_URL}/members`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(member),
    });
    
    if (response.ok) {
      await fetchMembers();
      memberForm.reset();
    }
  } catch (error) {
    console.error('Error adding member:', error);
  }
});

// Render members list
function renderMembers(searchTerm = '') {
  const filteredMembers = members.filter(member => 
    member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.email.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  membersList.innerHTML = filteredMembers.map(member => `
    <div class="member-card">
      <div class="member-info">
        <h3>${member.name}</h3>
        <p>📧 ${member.email}</p>
        <p>📱 ${member.phone}</p>
        <p>📅 Joined: ${member.joinDate}</p>
      </div>
      <div class="member-actions">
        <button onclick="deleteMember('${member._id}')" class="btn-delete">Delete</button>
      </div>
    </div>
  `).join('');
}

// Delete member
window.deleteMember = async (id) => {
  if (confirm('Are you sure you want to delete this member?')) {
    try {
      const response = await fetch(`${API_URL}/members/${id}`, {
        method: 'DELETE',
      });
      
      if (response.ok) {
        await fetchMembers();
      }
    } catch (error) {
      console.error('Error deleting member:', error);
    }
  }
};

// Search functionality
searchInput.addEventListener('input', (e) => {
  renderMembers(e.target.value);
});

// Initial fetch
fetchMembers();